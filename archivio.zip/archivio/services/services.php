
<?php

error_reporting(0);
header('Content-Type: application/json');
$post_request = file_get_contents('php://input');
define('SERVER', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', 'deamysql');
define('DATABASE', 'deagostini');

class Dragdrop {

    private $sql;
    private $mysql;
    private $result;
    private $result_rows;
    private $database_name;
    private static $instance;
    static $queries = array();

    public function __construct($post_request) {

        $this->database_name = DATABASE;
        $this->mysql = mysqli_connect(SERVER, USERNAME, PASSWORD, DATABASE);
        if (!$this->mysql) {
            throw new DatabaseException('Database connection error: ' . mysqli_connect_error());
        }
        $this->request = json_decode($post_request, true);

       

        if (isset($this->request['action'])) {

            if ($this->request['action'] == "create-folder") {
                $this->create_folder();
            }
            if ($this->request['action'] == "show-folder") {
                $this->show_folder();
            }
            if ($this->request['action'] == "delete-all-folder") {
                $this->delete_all_folder();
            }
            if ($this->request['action'] == "delete-folder") {
                $this->delete_folder();
            }
            if ($this->request['action'] == "get-folders") {
                $this->get_folders();
            }
            if ($this->request['action'] == "duplicate-folder") {
                $this->duplicate_folder();
            }
            if ($this->request['action'] == "breadcrumb-folder") {
                $this->breadcrumb_folder();
            }
            if ($this->request['action'] == "update-folder") {
                $this->update_folder();
            }
            if ($this->request['action'] == "delete-resource") {
                $this->delete_resource();
            }
        }
    }

    public function create_folder() {
        $result = array();
        if (isset($this->request)) {

            if (isset($this->request['pk_fid'])) {
                $save_data = $this->update(
                        'zm_folders', array('folder_name' => $this->request['folder_name'],
                        ), array('pk_fid' => $this->request['pk_fid']));
            } else {

                $save_data = $this->insert(
                        'zm_folders', array(
                    'folder_name' => $this->request['folder_name'],
                    'user_id' => $this->request['user_id'],
                    'status' => '1'));
                $last_id = $this->id();
                $insert_sub_data = $this->insert(
                        'zm_subfolders', array(
                    'fk_fid' => $last_id,
                    'fid' => isset($this->request['fid']) ? trim($this->request['fid']) : 1,
                    'status' => '1'));
            }
            if ($save_data) {
                $result = array("status" => true, "response" => isset($this->request['pk_fid']) ? 'Folder renamed Successfully' : 'Folder Created Successfully');
                echo json_encode($result);
            } else {
                $result = array("status" => false, "response" => isset($this->request['pk_fid']) ? 'Folder renamed Not Successfully' : 'Folder Created Not Successfully');
                echo json_encode($result);
            }
            return false;
        } else {
            $result = array("status" => false, "response" => "Invalid Request");
            echo json_encode($result);
        }
    }

    public function show_folder() {


        $this->query('select zf.pk_fid,zf.folder_name,zf.user_id,zsf.fk_fid,zsf.fid from zm_folders as zf inner join zm_subfolders as zsf on zsf.fk_fid=zf.pk_fid where zsf.fid=0');
        $result = $this->result_array();
        $temp = array();
        $ret_data = array();
        foreach ($result as $key => $values) {
            $sub_data = array();
            $temp[$values['pk_fid']]['id'] = $values['pk_fid'];
            $temp[$values['pk_fid']]['title'] = $values['folder_name'];
            $temp[$values['pk_fid']]['nodes'] = $this->leftcategory_data($values['pk_fid']);
        }
        if (!empty($temp)) {

            foreach ($temp as $value) {

                $ret_data[] = $value;
            }
        }

        $this->query('select * from zm_resources where status=1 and fk_fid=0');
        $resource_data = $this->result_array();

        echo json_encode(array("leftside" => $ret_data, "resources" => $resource_data));
    }

    public function leftcategory_data($parent) {
        $sub_data = array();
        $this->query('select zf.pk_fid,zf.folder_name,zf.user_id,zsf.fk_fid,zsf.fid from zm_folders as zf inner join zm_subfolders as zsf on zsf.fk_fid=zf.pk_fid where zsf.fid=' . $parent);
        $sub_data = $this->result_array();
        $category = array();
        $ret_data = array();

        foreach ($sub_data as $values) {
            $category[$values['pk_fid']]['id'] = $values['pk_fid'];
            $category[$values['pk_fid']]['title'] = $values['folder_name'];
            $category[$values['pk_fid']]['nodes'] = self::leftcategory_data($values['pk_fid']);
        }

        if (!empty($category)) {

            foreach ($category as $value) {

                $ret_data[] = $value;
            }
        }

        return $ret_data;
    }

    public function category_data($parent) {
        $sub_data = array();
        $this->query('select zf.pk_fid,zf.folder_name,zf.user_id,zsf.fk_fid,zsf.fid from zm_folders as zf inner join zm_subfolders as zsf on zsf.fk_fid=zf.pk_fid where zsf.fid=' . $parent);
        $sub_data = $this->result_array();
        $category = array();
        $ret_data = array();

        foreach ($sub_data as $values) {
            $category[$values['pk_fid']]['id'] = $values['pk_fid'];
            $category[$values['pk_fid']]['title'] = $values['folder_name'];
            $category[$values['pk_fid']]['nodes'] = self::category_data($values['pk_fid']);
            $this->query('select * from zm_resources where status=1 and fk_fid=' . $values['pk_fid']);
            $result_data = $this->result_array();
            foreach ($result_data as $datas) {
                array_push($category[$values['pk_fid']]['nodes'], array("id" => $datas['id'], "resourse_title" => $datas['resourse_title'], "resource_file" =>"http://localhost/ZONA_MATEMATICA/upload/" . $datas['resource_file']));
                //$category[$values['pk_fid']]['resources'][] = array("resource_code"=>$datas['resource_code'],"resourse_title"=>$datas['resourse_title']); 
            }
        }

        if (!empty($category)) {

            foreach ($category as $value) {

                $ret_data[] = $value;
            }
        }

        return $ret_data;
    }

    public function delete_all_folder() {
        if (isset($this->request['user_id'])) {
            $delete_record = $this->delete_query("DELETE zm_folders, zm_subfolders FROM zm_folders  INNER JOIN zm_subfolders ON zm_folders.pk_fid = zm_subfolders.fk_fid WHERE zm_folders.user_id=" . $this->request['user_id']);

            //Resource Delete
            $this->delete_query("DELETE FROM  zm_resources WHERE fk_fid!=0 and user_id=" . $this->request['user_id']);


            if ($delete_record > 0) {
                $result = array("status" => true, "response" => 'Folder Deleted Successfully');
            } else {
                $result = array("status" => false, "response" => 'Folder Deleted Not Successfully');
            }
            echo json_encode($result);
        } else {
            $result = array("status" => false, "response" => "Invalid Request");
            echo json_encode($result);
        }
    }

    public function delete_folder() {
        if (isset($this->request['user_id']) && isset($this->request['pk_fid'])) {
            //Delete Sub Folder
            $delete_record = $this->delete_query("DELETE zm_folders, zm_subfolders FROM zm_folders  INNER JOIN zm_subfolders ON zm_folders.pk_fid = zm_subfolders.fk_fid WHERE zm_folders.user_id=" . $this->request['user_id'] . " and  zm_folders.pk_fid=" . $this->request['pk_fid']);
            //Resource Delete
            $this->delete_query("DELETE FROM  zm_resources WHERE fk_fid=" . $this->request['pk_fid']);
            //Get sub folders
            $this->query('select * from zm_subfolders where fid=' . $this->request['pk_fid']);
            $result_data = $this->result_array();
            foreach ($result_data as $values) {
                $this->delete_query("DELETE  FROM zm_folders  WHERE pk_fid=" . $values['fk_fid']);
                //Resource Delete
                $this->delete_query("DELETE FROM  zm_resources  WHERE fk_fid=" . $values['fk_fid']);
            }
            $this->delete_query("DELETE  FROM zm_subfolders  WHERE fid=" . $this->request['pk_fid']);


            if ($delete_record > 0) {
                $result = array("status" => true, "response" => 'Folder Deleted Successfully');
            } else {
                $result = array("status" => false, "response" => 'Folder Deleted Not Successfully');
            }
            echo json_encode($result);
        } else {
            $result = array("status" => false, "response" => "Invalid Request");
            echo json_encode($result);
        }
    }

    public function get_folders() {

        if (isset($this->request['user_id']) && isset($this->request['pk_fid'])) {

            //Sub Folder            
            $sub_folder_result = $this->category_data($this->request['pk_fid']);

            //Resource
            //$this->query('select resource_code,resourse_title,concat("http://localhost/ZONA_MATEMATICA/upload/",resource_file) as resource_file from zm_resources where status=1 and fk_fid=' . $this->request['pk_fid']);
	        $this->query('select archivio.id as id, archivio.resource_code as code, risorse.title as title, risorse.learning_type as tipo from zm_resources as archivio inner join dea_resources as risorse on archivio.resource_code=risorse.resource_code where archivio.status=1 and archivio.fk_fid=' . $this->request['pk_fid']);
	        $resource_data = $this->result_array();

            //Main Folder
            $this->query('select zf.pk_fid,zf.folder_name,zf.user_id,zsf.fk_fid,zsf.fid from zm_folders as zf inner join zm_subfolders as zsf on zsf.fk_fid=zf.pk_fid where zsf.fid=0 and zf.user_id=' . $this->request['user_id']);
            $main_folder_result = $this->result_array();
            $temp = array();
            $ret_data = array();
            foreach ($main_folder_result as $key => $values) {
                $sub_data = array();
                $temp[$values['pk_fid']]['id'] = $values['pk_fid'];
                $temp[$values['pk_fid']]['title'] = $values['folder_name'];
                $temp[$values['pk_fid']]['nodes'] = $this->leftcategory_data($values['pk_fid']);
            }
            if (!empty($temp)) {

                foreach ($temp as $value) {

                    $ret_data[] = $value;
                }
            }
            $data = array("status" => true, "subfolder" => $sub_folder_result, 'resources' => $resource_data, 'leftside' => $ret_data);
            echo json_encode($data);
        } else {
            $result = array("status" => false, "response" => "Invalid Request");
            echo json_encode($result);
        }
    }

    //Duplicate Folder
    public function duplicate_folder() {
        if (isset($this->request['user_id']) && isset($this->request['pk_fid']) && isset($this->request['title'])) {
            $this->query('select * from zm_folders where pk_fid=' . $this->request['pk_fid']);
            $check_data = $this->result_array();
            if (count($check_data) > 0) {
                //Check Parent Data
                $this->query('select * from zm_subfolders where fk_fid=' . $this->request['pk_fid']);
                $get_data = $this->result_array();
                //Insert Duplicate Folder
                $save_data = $this->insert(
                        'zm_folders', array(
                    'folder_name' => "Copy " . $this->request['title'],
                    'user_id' => $this->request['user_id'],
                    'status' => '1'));
                $fk_fid = $this->id();
                $insert_sub_data = $this->insert(
                        'zm_subfolders', array(
                    'fk_fid' => $fk_fid,
                    'fid' => $get_data[0]['fid'],
                    'status' => '1'));
                //Resource
                $this->query('select id,resource_code from zm_resources where status=1 and fk_fid=' . $this->request['pk_fid']);
                $resource_data = $this->result_array();

                foreach ($resource_data as $resource_val) {
                        $save_resource_data = $this->insert(
	                        'zm_resources', array(
	                        'resource_code' => $resource_val['resource_code'],
                            'user_id' => $this->request['user_id'],
                            'fk_fid' => $fk_fid,
                            'status' => '1'));
                }

                $sub_folder_result = $this->category_data($this->request['pk_fid']);

                foreach ($sub_folder_result as $values) {
                    $dp_save_data = $this->insert(
                            'zm_folders', array(
                        'folder_name' => "Copy " . $values['title'],
                        'user_id' => $this->request['user_id'],
                        'status' => '1'));
                    $dp_fk_fid = $this->id();
                    $dp_insert_sub_data = $this->insert(
                            'zm_subfolders', array(
                        'fk_fid' => $dp_fk_fid,
                        'fid' => $fk_fid,
                        'status' => '1'));
                    $sub_folders = $this->update_duplicate_data($values['id'], $dp_fk_fid);

                    $this->query('select id,resource_code from zm_resources where fk_fid=' . $values['id']);
                    $resources = $this->result_array();

                    foreach ($resources as $resource_val) {
	                    $save_resource_data = $this->insert(
		                    'zm_resources', array(
		                    'resource_code' => $resource_val['resource_code'],
		                    'user_id' => $this->request['user_id'],
		                    'fk_fid' => $fk_fid,
		                    'status' => '1'));
                    }
                }

                if ($save_data) {
                    $result = array("status" => true, "response" => 'Duplicate Folder Created Successfully');
                    echo json_encode($result);
                } else {
                    $result = array("status" => false, "response" => 'Duplicate Folder Created Not Successfully');
                    echo json_encode($result);
                }
            } else {
                $result = array("status" => false, "response" => 'Duplicate Folder Created Not Successfully');
                echo json_encode($result);
            }
        } else {
            $result = array("status" => false, "response" => "Invalid Request");
            echo json_encode($result);
        }
    }

    public function update_duplicate_data($parent, $dp_fk_fid) {
        $sub_data = array();
        $this->query('select zf.pk_fid,zf.folder_name,zf.user_id,zsf.fk_fid,zsf.fid from zm_folders as zf inner join zm_subfolders as zsf on zsf.fk_fid=zf.pk_fid where zsf.fid=' . $parent);
        $sub_data = $this->result_array();
        $category = array();
        $ret_data = array();

        foreach ($sub_data as $values) {

            $save_data = $this->insert(
                    'zm_folders', array(
                'folder_name' => "Copy " . $values['folder_name'],
                'user_id' => $values['user_id'],
                'status' => '1'));
            $fk_fid = $this->id();
            $insert_sub_data = $this->insert(
                    'zm_subfolders', array(
                'fk_fid' => $fk_fid,
                'fid' => $dp_fk_fid,
                'status' => '1'));
            self::update_duplicate_data($values['pk_fid'], $fk_fid);
            $this->query('select * from zm_resources where fk_fid=' . $values['pk_fid']);
            $resources = $this->result_array();
            foreach ($resources as $resource_val) {
	            $save_resource_data = $this->insert(
		            'zm_resources', array(
		            'resource_code' => $resource_val['resource_code'],
		            'user_id' => $this->request['user_id'],
		            'fk_fid' => $fk_fid,
		            'status' => '1'));
            }
        }
    }

    public function breadcrumb_folder() {
        if (isset($this->request['user_id']) && isset($this->request['pk_fid'])) {

            //breadcrump_folder     
            $breadcrump_folder_result = $this->breadcrumb_data($this->request['pk_fid']);

            $result = array("status" => true, "response" => $breadcrump_folder_result);
            echo json_encode($result);
        } else {
            $result = array("status" => false, "response" => "Invalid Request");
            echo json_encode($result);
        }
    }

    public function breadcrumb_data($parent) {
        global $ret_data;
        $sub_data = array();
        $this->query('select zf.pk_fid,zf.folder_name,zf.user_id,zsf.fk_fid,zsf.fid from zm_folders as zf inner join zm_subfolders as zsf on zsf.fk_fid=zf.pk_fid where zsf.fk_fid=' . $parent);
        $sub_data = $this->result_array();
        $category = array();
        if (count($sub_data) > 0) {
            $category[$sub_data[0]['pk_fid']][] = array('id' => $sub_data[0]['pk_fid'], 'title' => $sub_data[0]['folder_name']);
            self::breadcrumb_data($sub_data[0]['fid']);
        }
        if (!empty($category)) {

            foreach ($category as $key => $value) {

                $ret_data[] = $value[0];
            }
        }

        return $ret_data;
    }

    public function update_folder() {

        if ($this->request['data']) {
            foreach ($this->request['data'] as $key => $value) {
                if ($key == 'dest') {
                    $this->updatetree($value['nodes'], $value['id']);
                }
                if ($key == 'trash') {
                    foreach ($value as $trash) {
                        if (isset($trash['nodes'][0]['id'])) {
                            $this->query("update  zm_resources set status=0  WHERE id=" . $trash['nodes'][0]['id']);
                        }
                        if (isset($trash['nodes'][0]['id'])) {
                            $delete_record = $this->delete_query("DELETE zm_folders, zm_subfolders FROM zm_folders  INNER JOIN zm_subfolders ON zm_folders.pk_fid = zm_subfolders.fk_fid WHERE zm_folders.pk_fid=" . $trash['nodes'][0]['id']);
                            //Resource Delete
                            $this->query("update  zm_resources set status=0  WHERE fk_fid=" . $trash['nodes'][0]['id']);
                            //Get sub folders
                            $this->query('select * from zm_subfolders where fid=' . $trash['nodes'][0]['id']);
                            $result_data = $this->result_array();
                            foreach ($result_data as $values) {
                                $this->delete_query("DELETE  FROM zm_folders  WHERE pk_fid=" . $values['fk_fid']);
                                //Resource Delete
                                $this->query("update  zm_resources set status=0  WHERE fk_fid=" . $values['fk_fid']);
                            }
                            $this->delete_query("DELETE  FROM zm_subfolders  WHERE fid=" . $trash['nodes'][0]['id']);
                        }
                    }
                }
            }
            $result = array("status" => TRUE);
            echo json_encode($result);
        } else {
            $result = array("status" => false, "response" => "Invalid Request");
            echo json_encode($result);
        }
    }

    public function updatetree($inarr = array(), $p_id = 0) {
        foreach ($inarr as $key => $value) {
            if (isset($value['id'])) {
                $this->update('zm_resources', array('fk_fid' => $p_id), array('id' => $value['id']));
            } else {
                $this->update('zm_subfolders', array('fid' => $p_id), array('fk_fid' => $value['id']));
                //if (isset($value['nodes']) && count($value['nodes'])) {
                    //$this->updatetree($value['nodes'], $value['id']);
                //}
            }
        }
    }

    //Delete Resource
    public function delete_resource() {
        if (isset($this->request['id'])) {
            //Resource Delete
            //$delete_record = $this->query("update  zm_resources set status=0 WHERE fk_fid=" . $this->request['pk_fid']);
            $delete_record = $this->update(
                    'zm_resources', array('status' => 0,
                    ), array('id' => $this->request['id']));

            if ($delete_record) {
                $result = array("status" => true, "response" => 'Resource Deleted Successfully');
            } else {
                $result = array("status" => false, "response" => 'Resource Deleted Not Successfully');
            }
            echo json_encode($result);
        } else {
            $result = array("status" => false, "response" => "Invalid Request");
            echo json_encode($result);
        }
    }

    //Query Data Start
    private function _error($error) {
        throw new DatabaseException('Database error: ' . $error);
    }

    public function process_where($where, $where_mode = 'AND') {
        $query = '';
        if (is_array($where)) {
            $num = 0;
            $where_count = count($where);
            foreach ($where as $k => $v) {
                if (is_array($v)) {
                    $w = array_keys($v);
                    if (reset($w) != 0) {
                        throw new Exception('Can not handle associative arrays');
                    }
                    $query .= " `" . $k . "` IN (" . $this->join_array($v) . ")";
                } elseif (!is_integer($k)) {
                    $query .= ' `' . $k . "`='" . $this->escape($v) . "'";
                } else {
                    $query .= ' ' . $v;
                }
                $num++;
                if ($num != $where_count) {
                    $query .= ' ' . $where_mode;
                }
            }
        } else {
            $query .= ' ' . $where;
        }
        return $query;
    }

    public function select($table, $where = array(), $limit = false, $order = false, $where_mode = "AND", $select_fields = '*') {
        $this->result = null;
        $this->sql = null;

        if (is_array($select_fields)) {
            $fields = '';
            foreach ($select_fields as $s) {
                $fields .= '`' . $s . '`, ';
            }
            $select_fields = rtrim($fields, ', ');
        }

        $query = 'SELECT ' . $select_fields . ' FROM `' . $table . '`';
        if (!empty($where)) {
            $query .= ' WHERE' . $this->process_where($where, $where_mode);
        }
        if ($order) {
            $query .= ' ORDER BY ' . $order;
        }
        if ($limit) {
            $query .= ' LIMIT ' . $limit;
        }
        return $this->query($query);
    }

    public function query($query) {
        self::$queries[] = $query;
        $this->sql = $query;

        $this->result_rows = null;
        $this->result = mysqli_query($this->mysql, $query);

        if (mysqli_error($this->mysql) != '') {
            $this->_error(mysqli_error($this->mysql));
            $this->result = null;
            return $this;
        }

        return $this;
    }

    public function sql() {
        return $this->sql;
    }

    public function result($key_field = null) {
        if (!$this->result_rows) {
            $this->result_rows = array();
            while ($row = mysqli_fetch_assoc($this->result)) {
                $this->result_rows[] = $row;
            }
        }

        $result = array();
        $index = 0;

        foreach ($this->result_rows as $row) {
            $key = $index;
            if (!empty($key_field) && isset($row[$key_field])) {
                $key = $row[$key_field];
            }
            $result[$key] = new stdClass();
            foreach ($row as $column => $value) {
                $this->is_serialized($value, $value);
                $result[$key]->{$column} = $this->clean($value);
            }
            $index++;
        }
        return $result;
    }

    public function result_array() {
        if (!$this->result_rows) {
            $this->result_rows = array();
            while ($row = mysqli_fetch_assoc($this->result)) {
                $this->result_rows[] = $row;
            }
        }
        $result = array();
        $n = 0;
        foreach ($this->result_rows as $row) {
            $result[$n] = array();
            foreach ($row as $k => $v) {
                $this->is_serialized($v, $v);
                $result[$n][$k] = $this->clean($v);
            }
            $n++;
        }
        return $result;
    }

    public function row($index = 0) {
        if (!$this->result_rows) {
            $this->result_rows = array();
            while ($row = mysqli_fetch_assoc($this->result)) {
                $this->result_rows[] = $row;
            }
        }

        $num = 0;
        foreach ($this->result_rows as $column) {
            if ($num == $index) {
                $row = new stdClass();
                foreach ($column as $key => $value) {
                    $this->is_serialized($value, $value);
                    $row->{$key} = $this->clean($value);
                }
                return $row;
            }
            $num++;
        }

        return new stdClass();
    }

    public function row_array($index = 0) {
        if (!$this->result_rows) {
            $this->result_rows = array();
            while ($row = mysqli_fetch_assoc($this->result)) {
                $this->result_rows[] = $row;
            }
        }

        $num = 0;
        foreach ($this->result_rows as $column) {
            if ($num == $index) {
                $row = array();
                foreach ($column as $key => $value) {
                    $this->is_serialized($value, $value);
                    $row[$key] = $this->clean($value);
                }
                return $row;
            }
            $num++;
        }

        return array();
    }

    public function count() {
        if ($this->result) {
            return mysqli_num_rows($this->result);
        } elseif (isset($this->result_rows)) {
            return count($this->result_rows);
        } else {
            return false;
        }
    }

    public function num($table = null, $where = array(), $limit = false, $order = false, $where_mode = "AND") {
        if (!empty($table)) {
            $this->select($table, $where, $limit, $order, $where_mode, 'COUNT(*)');
        }

        $res = $this->row();
        return $res->{'COUNT(*)'};
    }

    function table_exists($name) {
        $res = mysqli_query($this->mysql, "SELECT COUNT(*) AS count FROM information_schema.tables WHERE table_schema = '" . $this->escape($this->database_name) . "' AND table_name = '" . $this->escape($name) . "'");
        return ($this->mysqli_result($res, 0) == 1);
    }

    private function join_array($array) {
        $nr = 0;
        $query = '';
        foreach ($array as $key => $value) {
            if (is_object($value) || is_array($value) || is_bool($value)) {
                $value = serialize($value);
            }
            $query .= " '" . $this->escape($value) . "'";
            $nr++;
            if ($nr != count($array)) {
                $query .= ',';
            }
        }
        return trim($query);
    }

    function insert($table, $fields = array(), $appendix = false, $ret = false) {
        $this->result = null;
        $this->sql = null;

        $query = 'INSERT INTO';
        $query .= ' `' . $this->escape($table) . "`";

        if (is_array($fields)) {
            $query .= ' (';
            $num = 0;
            foreach ($fields as $key => $value) {
                $query .= ' `' . $key . '`';
                $num++;
                if ($num != count($fields)) {
                    $query .= ',';
                }
            }
            $query .= ' ) VALUES ( ' . $this->join_array($fields) . ' )';
        } else {
            $query .= ' ' . $fields;
        }
        if ($appendix) {
            $query .= ' ' . $appendix;
        }
        if ($ret) {
            return $query;
        }
        $this->sql = $query;
        $this->result = mysqli_query($this->mysql, $query);
        if (mysqli_error($this->mysql) != '') {
            $this->_error(mysqli_error($this->mysql));
            $this->result = null;
            return false;
        } else {
            return $this->affected();
        }
    }

    function update($table, $fields = array(), $where = array(), $limit = false, $order = false) {
        if (empty($where)) {
            throw new DatabaseException('Where clause is empty for update method');
        }

        $this->result = null;
        $this->sql = null;
        $query = 'UPDATE `' . $table . '` SET';
        if (is_array($fields)) {
            $nr = 0;
            foreach ($fields as $k => $v) {
                if (is_object($v) || is_array($v) || is_bool($v)) {
                    $v = serialize($v);
                }
                $query .= ' `' . $k . "`='" . $this->escape($v) . "'";
                $nr++;
                if ($nr != count($fields)) {
                    $query .= ',';
                }
            }
        } else {
            $query .= ' ' . $fields;
        }
        if (!empty($where)) {
            $query .= ' WHERE' . $this->process_where($where);
        }
        if ($order) {
            $query .= ' ORDER BY ' . $order;
        }
        if ($limit) {
            $query .= ' LIMIT ' . $limit;
        }
        $this->sql = $query;
        $this->result = mysqli_query($this->mysql, $query);
        if (mysqli_error($this->mysql) != '') {
            $this->_error(mysqli_error($this->mysql));
            $this->result = null;
            return false;
        } else {
            return $this->affected();
        }
    }

    function delete($table, $where = array(), $where_mode = "AND", $limit = false, $order = false) {
        if (empty($where)) {
            throw new DatabaseException('Where clause is empty for update method');
        }

        $this->result = null;
        $this->sql = null;
        $query = 'DELETE FROM `' . $table . '`';
        if (!empty($where)) {
            $query .= ' WHERE' . $this->process_where($where, $where_mode);
        }
        if ($order) {
            $query .= ' ORDER BY ' . $order;
        }
        if ($limit) {
            $query .= ' LIMIT ' . $limit;
        }
        $this->sql = $query;

        $this->result = mysqli_query($this->mysql, $query);
        if (mysqli_error($this->mysql) != '') {
            $this->_error(mysqli_error($this->mysql));
            $this->result = null;
            return false;
        } else {
            return $this;
        }
    }

    public function id() {
        return mysqli_insert_id($this->mysql);
    }

    public function affected() {
        return mysqli_affected_rows($this->mysql);
    }

    public function escape($str) {
        return mysqli_real_escape_string($this->mysql, $str);
    }

    public function error() {
        return mysqli_error($this->mysql);
    }

    private function clean($str) {
        if (is_string($str)) {
            if (!mb_detect_encoding($str, 'UTF-8', TRUE)) {
                $str = utf8_encode($str);
            }
        }
        return $str;
    }

    public function is_serialized($data, &$result = null) {

        if (!is_string($data)) {
            return false;
        }

        $data = trim($data);

        if (empty($data)) {
            return false;
        }
        if ($data === 'b:0;') {
            $result = false;
            return true;
        }
        if ($data === 'b:1;') {
            $result = true;
            return true;
        }
        if ($data === 'N;') {
            $result = null;
            return true;
        }
        if (strlen($data) < 4) {
            return false;
        }
        if ($data[1] !== ':') {
            return false;
        }
        $lastc = substr($data, -1);
        if (';' !== $lastc && '}' !== $lastc) {
            return false;
        }

        $token = $data[0];
        switch ($token) {
            case 's' :
                if ('"' !== substr($data, -2, 1)) {
                    return false;
                }
                break;
            case 'a' :
            case 'O' :
                if (!preg_match("/^{$token}:[0-9]+:/s", $data)) {
                    return false;
                }
                break;
            case 'b' :
            case 'i' :
            case 'd' :
                if (!preg_match("/^{$token}:[0-9.E-]+;/", $data)) {
                    return false;
                }
        }

        try {
            if (($res = @unserialize($data)) !== false) {
                $result = $res;
                return true;
            }
            if (($res = @unserialize(utf8_encode($data))) !== false) {
                $result = $res;
                return true;
            }
        } catch (Exception $e) {
            return false;
        }

        return false;
    }

    private function mysqli_result($res, $row, $field = 0) {
        $res->data_seek($row);
        $datarow = $res->fetch_array();
        return $datarow[$field];
    }

    public function delete_query($query) {
        self::$queries[] = $query;
        $this->sql = $query;

        $this->result_rows = null;
        $this->result = mysqli_query($this->mysql, $query);

        if (mysqli_error($this->mysql) != '') {
            $this->_error(mysqli_error($this->mysql));
            $this->result = null;
            return $this;
        }

        return $this->affected();
    }

    ////Query Data End
}

$drag = new Dragdrop($post_request);
?>


