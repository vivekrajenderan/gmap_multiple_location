(function () {
  'use strict';

  angular.module('demoApp', ['ui.tree', 'ngRoute', 'ui.bootstrap','ui-notification','angularValidator'])

    .config(['$routeProvider', '$compileProvider', function ($routeProvider, $compileProvider) {
      $routeProvider
        .when('/', {
          controller: 'BasicExampleCtrl',
          templateUrl: 'views/template.html'
        })
        .otherwise({
          redirectTo: '/'
        });

      // testing issue #521
      $compileProvider.debugInfoEnabled(false);
    }]);
})();
