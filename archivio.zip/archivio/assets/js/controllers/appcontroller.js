(function () {
    'use strict';

    angular.module('demoApp')
            .controller('appCtrl', ['$scope', '$modal', '$http', 'Notification', '$route', '$routeParams', '$timeout', function ($scope, $modal, $http, Notification, $route, $routeParams, $timeout) {
                    $scope.firsttimeloadingdiv = true;
                }]);


}());
