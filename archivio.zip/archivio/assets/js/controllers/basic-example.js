(function () {
    'use strict';

    angular.module('demoApp')
            .controller('BasicExampleCtrl', ['$scope', '$modal', '$http', 'Notification', '$route', '$routeParams', '$rootScope', function ($scope, $modal, $http, Notification, $route, $routeParams, $rootScope) {
                    $scope.formval = {};
                    $scope.data = {};
                    $scope.optionshowdetail = {'show': false};
                    $scope.folderoptionshowdetail = {'show': true, 'idshow': []};
                    var subfolderindexcheck = '';
                    var tempindex = '';
                    $scope.templistdata = {};
                    $scope.rightsidecount = 0;
                    $scope.rightsidesubcount = 0;

                    // $rootScope define for folder id for folder details

                    if (!$rootScope.parameterid)
                        $rootScope.parameterid = '1';

                    // default function
                    $scope.remove = function (scope) {
                        scope.remove();
                    };

                    $scope.toggle = function (scope) {
                        scope.toggle();
                    };

                    // folder content details subfolder and resource

                    $scope.pagecontentcall = function () {
                        //$scope.$parent.firsttimeloadingdiv = true;
                        $http({method: 'POST', url: 'services/services.php', data: {'action': 'get-folders', 'user_id': '1', 'pk_fid': $rootScope.parameterid}, headers: {'Content-Type': 'application/json'}}).success(function (data) {
                            if (data) {
                                $http({method: 'POST', url: 'services/services.php', data: {'action': 'breadcrumb-folder', 'user_id': '1', 'pk_fid': $rootScope.parameterid}, headers: {'Content-Type': 'application/json'}}).success(function (result) {
                                    if (result.status) {
                                        //$scope.$parent.firsttimeloadingdiv = false;
                                        $scope.breadcrumb = result.response;
                                        angular.forEach(result.response, function (value1, key1) {
                                            $scope.folderoptionshowdetail.idshow.push(value1.id);
                                        });

                                    } else {
                                        Notification.error('server error !!');
                                        $route.reload();
                                    }
                                }).error(function (data) {
                                    Notification.error('server error !!');
                                });
                                data.trash = [{'nodes': []}];
                                subfolderindexcheck = JSON.stringify(data.subfolder);
                                tempindex = JSON.stringify(data);
                                $scope.data = data;
                                $scope.rightsidecount = $scope.data.subfolder.length;
                                console.log($scope.data.trash);
                                $scope.templistdata = data;
                            } else {
                                Notification.error('server error !!');
                            }
                        }).error(function (data) {
                            Notification.error('server error !!');
                        });
                    };
                    $scope.moveLastToTheBeginning = function () {
                        var a = $scope.data.pop();
                        $scope.data.splice(0, 0, a);
                    };

                    $scope.newSubItem = function (scope) {
                        var nodeData = scope.$modelValue;
                        nodeData.nodes.push({
                            id: nodeData.id * 10 + nodeData.nodes.length,
                            title: nodeData.title + '.' + (nodeData.nodes.length + 1),
                            nodes: []
                        });
                    };

                    // Add new folder form

                    $scope.addnewfolder = function (itemindex) {
                        if (typeof itemindex !== 'undefined') {
                            $scope.formval.fid = itemindex;
                            console.log($scope.formval);
                        }
                        var modalInstance;
                        modalInstance = $modal.open({
                            templateUrl: 'addfolder-modal.html',
                            size: 'sm',
                            controller: 'ModalInstanceCtrl',
                            scope: $scope
                        });
                    };

                    //folder detail call

                    $scope.viewdetailpage = function (itemindex) {
                        $rootScope.parameterid = itemindex;
                        $scope.pagecontentcall();
                        // console.log($rootScope.parameterid);
                    };

                    // Menu option show hide

                    $scope.optionshow = function (itemindex, show_side) {
                        if ($scope.optionshowdetail.show)
                            $scope.optionshowdetail.show = false;
                        else
                            $scope.optionshowdetail.show = true;
                        $scope.optionshowdetail.idshow = itemindex;
                        $scope.optionshowdetail.showside = show_side;
                    };

                    // Main folder list
                    $scope.formlistdata = function () {
                        //$scope.$parent.firsttimeloadingdiv = true;
                        $http({method: 'POST', url: 'services/services.php', data: {'action': 'show-folder'}, headers: {'Content-Type': 'application/json'}}).success(function (data) {
                            if (data) {
                                //$scope.$parent.firsttimeloadingdiv = false;
                                data.trash = [{'nodes': []}];
                                tempindex = JSON.stringify(data);
                                $scope.data = data;
                                data = {};
                                //$scope.templistdata = tempindex;
                            } else {
                                Notification.error('server error !!');
                            }
                        }).error(function (data) {
                            Notification.error('server error !!');
                        });
                    };

                    // Folder drag and drop update
                    var recursivefn = function (arr, indexval) {
                        angular.forEach(arr.leftside, function (value, key) {
                            console.log('summa');
                            console.log(value);
                            console.log(key);
                            console.log(value.id);
                            console.log(value.nodes.length);
                            console.log('summa1');
                            //  if(value.nodes.length > 0){
                            recursivefn(value.nodes, indexval);
                            // }
                        });

                    }

                    // service update for all drag and drop

                    $scope.servicecallfn = function (event) {
//                        console.log(event);
//                        console.log(event.source.nodeScope.node);
//                        console.log(event.dest.nodesScope.node);
                         $scope.data1 = { };
                        $scope.data1.dest = event.dest.nodesScope.node;
                        $scope.data1.dest1 = '';
                        var urlparam;
                            urlparam =  {method: 'POST', url: 'services/services.php', data: {'action': 'update-folder', 'data': $scope.data1, 'openfolder': $rootScope.parameterid, 'move':'lefttoright'}, headers: {'Content-Type': 'application/json'}};
                        if($scope.data.trash.length > 1){
                            $scope.pagecontentcall();
                        }
                        if ($scope.data.trash[0].nodes.length > 0) {
                            var modalInstance;
                            modalInstance = $modal.open({
                                templateUrl: 'deletecofirm-modal.html',
                                size: 'sm',
                                controller: 'ModalInstanceCtrl',
                                scope: $scope
                            });
                        } else {
                            //console.log('equal');
                            if (tempindex == angular.toJson($scope.data))
                                console.log('equal');
                            else {
                                console.log('not-equal');
                                //console.log($scope.data);
                                if (subfolderindexcheck == angular.toJson($scope.data.subfolder)) {
                                    delete $scope.data.subfolder;
                                } else {
                                    console.log('not-equal');
                                }
                                $http(urlparam).success(function (data) {
                                    if (data.status) {
                                        Notification.success('Updated succesfully');
                                        $scope.pagecontentcall();
                                    } else {
                                        Notification.error('Action failed !!');
                                        $route.reload();
                                    }
                                }).error(function (data) {
                                    Notification.error('server error !!');
                                });
                            }
                        }
                    };

                    // Rename the folder

                    $scope.renamefolder = function (indexitem, indextitle) {
                        console.log('rename');
                        console.log(indexitem);
                        $scope.formval.pk_fid = indexitem;
                        $scope.formval.folder_name = indextitle;
                        var modalInstance;
                        modalInstance = $modal.open({
                            templateUrl: 'addfolder-modal.html',
                            size: 'sm',
                            controller: 'ModalInstanceCtrl',
                            scope: $scope
                        });

                    };

                    // Duplicate the folder

                    $scope.duplicatefolder = function (indexitem, itemtitle) {
                        $http({method: 'POST', url: 'services/services.php', data: {'action': 'duplicate-folder', 'user_id': '1', 'pk_fid': indexitem, 'title': itemtitle}, headers: {'Content-Type': 'application/json'}}).success(function (data) {
                            if (data.status) {
                                Notification.success(data.response);
                                $route.reload();
                            } else {
                                Notification.error('Folder deletion failed !!');
                                $route.reload();
                            }
                        }).error(function (data) {
                            Notification.error('server error !!');
                        });
                    };

                    // Delete the folder

                    $scope.deletefolder = function (indexitem) {
                        $scope.deletecofirmID_tree = indexitem;
                        var modalInstance;
                        modalInstance = $modal.open({
                            templateUrl: 'deletecofirmleft-modal.html',
                            size: 'sm',
                            controller: 'ModalInstanceCtrl',
                            scope: $scope
                        });
                    };

                    // All folder delete

                    $scope.deletfolderconfirm = function () {
                        var modalInstance;
                        modalInstance = $modal.open({
                            templateUrl: 'deletecofirm-modal.html',
                            size: 'sm',
                            controller: 'ModalInstanceCtrl',
                            scope: $scope
                        });
                    };
                    $scope.trashresource = function (itemindex) {
                        var modalInstance;
                        $scope.trashresourceitemid = itemindex;
                        modalInstance = $modal.open({
                            templateUrl: 'trashresource-modal.html',
                            size: 'sm',
                            controller: 'ModalInstanceCtrl',
                            scope: $scope
                        });
                    };

                    // folder collapse and expand
                    $scope.collapseparticular = function (itemindex) {
                        if ($scope.folderoptionshowdetail.show) {
                            $scope.folderoptionshowdetail.show = false;
                        } else {
                            $scope.folderoptionshowdetail.show = true;
                        }
                        if ($scope.folderoptionshowdetail.idshow.indexOf(itemindex) < 0) {
                            $scope.folderoptionshowdetail.idshow.push(itemindex);
                        } else {
                            $scope.folderoptionshowdetail.idshow.splice($scope.folderoptionshowdetail.idshow.indexOf(itemindex));
                        }
                    };
                    $scope.getPClass = function (path, inputid) {
                        var re = false;
                        angular.forEach(path, function (value1, key1) {
                            if (!re && inputid === value1) {
                                re = true;
                            }
                        });

                        return re;
                    };
                    $scope.collapseAll = function () {
                        $scope.$broadcast('angular-ui-tree:collapse-all');
                    };
                    $scope.expandAll = function () {
                        $scope.$broadcast('angular-ui-tree:expand-all');
                    };

                    if ($rootScope.parameterid) {
                        $scope.pagecontentcall();
                    }


                }]);

    angular.module('demoApp')
            .controller('ModalInstanceCtrl', function ($scope, $http, $modalInstance, Notification, $route) {

                $scope.closeModal = function () {
                    $modalInstance.close();
                }

                $scope.deleteall = function () {
                    delete $scope.data.subfolder;
                    $http({method: 'POST', url: 'services/services.php', data: {'action': 'update-folder', 'data': $scope.data}, headers: {'Content-Type': 'application/json'}}).success(function (data) {
                        if (data.status) {
                            Notification.success('Folder deletion succesfully');
                            $modalInstance.close();
                            $route.reload();
                        } else {
                            Notification.error('Action failed !!');
                            $modalInstance.close();
                            $route.reload();
                        }
                    }).error(function (data) {
                        $modalInstance.close();
                        Notification.error('server error !!');
                    });
                };

                $scope.canceldeleteall = function () {
                    $modalInstance.close();
                    $route.reload();
                };
                $scope.deleteresource = function (trashresourceitemid) {
                    console.log(trashresourceitemid);
                    $http({method: 'POST', url: 'services/services.php', data: {'action': 'delete-resource', 'id': trashresourceitemid}, headers: {'Content-Type': 'application/json'}}).success(function (data) {
                        if (data.status) {
                            Notification.success(data.response);
                            $modalInstance.close();
                            $route.reload();
                        } else {
                            Notification.error('Action failed !!');
                            $modalInstance.close();
                            $route.reload();
                        }
                    }).error(function (data) {
                        $modalInstance.close();
                        Notification.error('server error !!');
                    });
                };

                $scope.foldercreater = function () {
                    //console.log($scope.formval.folder_name);
                    if ($scope.formval.folder_name && typeof ($scope.formval.folder_name) != 'undefined') {
                        $scope.formval.action = "create-folder";
                        $scope.formval.user_id = "1";
                        $http({method: 'POST', url: 'services/services.php', data: $scope.formval, headers: {'Content-Type': 'application/json'}}).success(function (data) {
                            if (data.status) {
                                Notification.success(data.response);
                                $modalInstance.close();
                                $route.reload();
                                $scope.formval = {};
                                $scope.addfolderform.reset();
                            } else {
                                Notification.error('Folder creation failed !!');
                                $modalInstance.close();
                                $route.reload();
                            }
                        }).error(function (data) {
                            $modalInstance.close();
                            Notification.error('server error !!');
                        });
                    } else {
                        Notification.error('Folder name should not be empty');
                    }
                };
                $scope.erase_left_field = function(itemindex){
                    $http({method: 'POST', url: 'services/services.php', data: {'action': 'delete-folder', 'user_id': '1', 'pk_fid': itemindex}, headers: {'Content-Type': 'application/json'}}).success(function (data) {
                        if (data.status) {
                            Notification.success(data.response);
                            $modalInstance.close();
                            $route.reload();
                        } else {
                            Notification.error('Folder deletion failed !!');
                            $modalInstance.close();
                            $route.reload();
                        }
                    }).error(function (data) {
                        $modalInstance.close();
                        Notification.error('server error !!');
                    });
                };
            });

}());
